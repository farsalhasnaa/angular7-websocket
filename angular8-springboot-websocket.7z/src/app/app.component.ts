import { Component } from '@angular/core';

import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular8-springboot-websocket';
  webSocketEndPoint: string = 'http://localhost:5656/live-temperature';
  topic: string = "/topic/temperature";
  stompClient: any;
  from: any;
  to: any;
  greeting: any ;
  name: string;
  ngOnInit() {
    console.log("Initialize WebSocket Connection");
    let ws = new SockJS(this.webSocketEndPoint);
    this.stompClient = Stomp.over(ws);
    const _this = this;
    _this.stompClient.connect({}, function (frame) {
        _this.stompClient.subscribe(_this.topic, function (message) {
            console.log(JSON.stringify(message.body));
            _this.onMessageReceived(JSON.stringify(message.body));
        });
    });
  }

  onSelect(from,to){
    console.log("Generating Report from: "+from+" till "+to+"");
    this.from = from;
    this.to = to;
  }

  weeklyReport(){
    console.log("generate weekly report...");
  }
  monthlyReport(){
    console.log("generate monthly report...");
  }
  yearlyReport(){
    console.log("generate yearly report...");
  }
  generateReport(message){
    console.log("Generate report: under proccessing...");
  }

  onMessageReceived(message){
    this.greeting.push(message);
  }
}